// Bot bidding intelligence system
const BotAI = {
    // Team strategies
    teamStrategies: {
        1: { // Mumbai Indians
            priorities: ['batsman', 'all-rounder'],
            budget: 'aggressive',
            focusOnStars: true
        },
        2: { // Chennai Super Kings
            priorities: ['all-rounder', 'spinner'],
            budget: 'balanced',
            focusOnExperience: true
        },
        3: { // Royal Challengers Bangalore
            priorities: ['batsman', 'fast bowler'],
            budget: 'aggressive',
            focusOnStars: true
        },
        4: { // Kolkata Knight Riders
            priorities: ['spinner', 'all-rounder'],
            budget: 'conservative',
            focusOnValue: true
        },
        5: { // Delhi Capitals
            priorities: ['fast bowler', 'batsman'],
            budget: 'balanced',
            focusOnYouth: true
        },
        6: { // Punjab Kings
            priorities: ['batsman', 'wicket-keeper'],
            budget: 'aggressive',
            focusOnStars: true
        },
        7: { // Rajasthan Royals
            priorities: ['all-rounder', 'uncapped'],
            budget: 'value-based',
            focusOnPotential: true
        },
        8: { // Sunrisers Hyderabad
            priorities: ['fast bowler', 'overseas'],
            budget: 'balanced',
            focusOnBowling: true
        },
        9: { // Lucknow Super Giants
            priorities: ['wicket-keeper', 'all-rounder'],
            budget: 'balanced',
            focusOnBalance: true
        },
        10: { // Gujarat Titans
            priorities: ['all-rounder', 'fast bowler'],
            budget: 'conservative',
            focusOnValue: true
        }
    },

    // Calculate team interest in a player
    calculateInterest(team, player) {
        let interest = 0.5; // Base interest
        
        const strategy = this.teamStrategies[team.id];
        if (!strategy) return interest;
        
        // Role priority
        if (strategy.priorities.includes(player.role.toLowerCase())) {
            interest += 0.3;
        }
        
        // Category preferences
        if (strategy.focusOnStars && player.category === 'capped' && player.basePrice >= 1.5) {
            interest += 0.2;
        }
        
        if (strategy.focusOnYouth && player.age <= 25) {
            interest += 0.15;
        }
        
        if (strategy.focusOnExperience && player.age >= 30) {
            interest += 0.1;
        }
        
        if (strategy.focusOnPotential && player.category === 'uncapped') {
            interest += 0.25;
        }
        
        if (strategy.focusOnValue && player.basePrice <= 1.0) {
            interest += 0.2;
        }
        
        // Budget considerations
        const budgetRatio = team.purse / 100;
        if (strategy.budget === 'conservative' && budgetRatio < 0.3) {
            interest -= 0.2;
        } else if (strategy.budget === 'aggressive' && budgetRatio > 0.7) {
            interest += 0.2;
        }
        
        // Team needs
        const roleCount = team.players.filter(p => p.role === player.role).length;
        if (roleCount === 0) {
            interest += 0.3; // High need for this role
        } else if (roleCount >= 3) {
            interest -= 0.2; // Already have enough of this role
        }
        
        // Overseas limit
        if (player.category === 'overseas' && team.overseasPlayers >= 3) {
            interest -= 0.5;
        }
        
        return Math.max(0, Math.min(1, interest));
    },

    // Determine if team should bid
    shouldBid(team, player, currentBid) {
        const interest = this.calculateInterest(team, player);
        const nextBid = currentBid + 0.25;
        
        // Can't afford
        if (team.purse < nextBid) return false;
        
        // Squad full
        if (team.players.length >= team.maxPlayers) return false;
        
        // Overseas limit
        if (player.category === 'overseas' && team.overseasPlayers >= team.maxOverseas) return false;
        
        // Calculate maximum bid based on interest and budget
        const budgetFactor = team.purse / 100;
        const maxBid = player.basePrice * (1 + interest * 3) * budgetFactor;
        
        if (nextBid > maxBid) return false;
        
        // Random factor for unpredictability
        const randomFactor = Math.random();
        return interest * randomFactor > 0.3;
    }
};

// Bot bidding logic
function botBidLogic() {
    if (!currentPlayer || bidTimer <= 0) return;
    
    // Get eligible teams
    let eligibleTeams = teams.filter(team => {
        return BotAI.shouldBid(team, currentPlayer, currentBid);
    });
    
    // Remove user team from bot bidding if not in auto mode
    if (userTeam && !autoPlayMode) {
        eligibleTeams = eligibleTeams.filter(team => team.id !== userTeam.id);
    }
    
    if (eligibleTeams.length === 0) return;
    
    // Sort teams by interest level
    const interestedTeams = eligibleTeams.map(team => ({
        team,
        interest: BotAI.calculateInterest(team, currentPlayer)
    })).sort((a, b) => b.interest - a.interest);
    
    // Higher chance for more interested teams
    const weights = interestedTeams.map((item, index) => 
        Math.pow(2, interestedTeams.length - index)
    );
    
    const totalWeight = weights.reduce((sum, w) => sum + w, 0);
    let random = Math.random() * totalWeight;
    
    let selectedTeam = null;
    for (let i = 0; i < interestedTeams.length; i++) {
        random -= weights[i];
        if (random <= 0) {
            selectedTeam = interestedTeams[i].team;
            break;
        }
    }
    
    if (!selectedTeam) return;
    
    // Place bid
    const nextBid = currentBid + 0.25;
    currentBid = nextBid;
    currentBidder = selectedTeam;
    
    updateBidDisplay();
    if (selectedTeam.id === userTeam?.id) {
        updateUserTeamInfo();
    }
    resetBidTimer();
    
    const logType = selectedTeam.id === userTeam?.id ? "user-bot-bid" : "bot-bid";
    const prefix = selectedTeam.id === userTeam?.id ? "🤖 You (Auto)" : `🤖 ${selectedTeam.shortName}`;
    addToAuctionLog(`${prefix} bid ₹${currentBid.toFixed(2)} Cr for ${currentPlayer.name}!`, logType);
    
    // Chain more bot bids with decreasing probability
    if (Math.random() < 0.6 && bidTimer > 8) {
        setTimeout(() => {
            if (currentPlayer && bidTimer > 5) {
                botBidLogic();
            }
        }, 1500 + Math.random() * 2000);
    }
}

// Enhanced bot behavior patterns
const BotBehavior = {
    // Bidding war logic
    escalateBidding(player, currentBid) {
        const starPlayers = ['Virat Kohli', 'Rohit Sharma', 'Jasprit Bumrah', 'David Warner'];
        
        if (starPlayers.includes(player.name)) {
            // Star players create more bidding wars
            return Math.random() < 0.8;
        }
        
        if (player.category === 'uncapped' && currentBid < 2.0) {
            // Value picks get competitive bidding
            return Math.random() < 0.6;
        }
        
        return Math.random() < 0.4;
    },

    // Last second bidding
    lastSecondBid() {
        return bidTimer <= 3 && Math.random() < 0.3;
    },

    // Strategic passing
    strategicPass(team, player, currentBid) {
        // Pass if bid is too high relative to player value
        const valueThreshold = player.basePrice * 2.5;
        if (currentBid > valueThreshold) return true;
        
        // Pass if team is running low on budget
        if (team.purse < 20 && currentBid > 3.0) return true;
        
        return false;
    }
};

// Initialize bot personalities
teams.forEach(team => {
    team.botPersonality = {
        aggression: Math.random() * 0.6 + 0.2, // 0.2 to 0.8
        patience: Math.random() * 0.5 + 0.3,   // 0.3 to 0.8
        riskTaking: Math.random() * 0.7 + 0.1  // 0.1 to 0.8
    };
});