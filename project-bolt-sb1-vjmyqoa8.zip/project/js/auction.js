let currentPlayer = null;
let currentPlayerIndex = 0;
let playerQueue = [...players];
let currentBid = 0;
let currentBidder = null;
let bidTimer = 15;
let timerInterval = null;
let auctionStartTime = Date.now();
let auctionLog = [];
let userTeam = null;
let autoPlayMode = false;

// DOM Elements
const currentPlayerEl = document.getElementById('currentPlayer');
const teamsGridEl = document.getElementById('teamsGrid');
const playersQueueEl = document.getElementById('playersQueue');
const auctionLogEl = document.getElementById('auctionLog');
const rulesModal = document.getElementById('rulesModal');
const teamSelectionModal = document.getElementById('teamSelectionModal');
const myTeamModal = document.getElementById('myTeamModal');

// Initialize auction
function initAuction() {
    renderTeamSelection();
}

function renderTeamSelection() {
    const teamSelectionGrid = document.getElementById('teamSelectionGrid');
    teamSelectionGrid.innerHTML = teams.map(team => `
        <div class="team-selection-card" onclick="selectUserTeam(${team.id})" data-team-id="${team.id}">
            <div class="team-logo" style="color: ${team.color}">
                ${team.shortName}
            </div>
            <div class="team-selection-name">${team.name}</div>
            <div class="team-selection-short">${team.shortName}</div>
        </div>
    `).join('');
    
    teamSelectionGrid.innerHTML += `
        <button class="confirm-selection" onclick="startAuction()" id="confirmBtn" style="display: none; grid-column: 1 / -1;">
            Start Auction
        </button>
    `;
}

function selectUserTeam(teamId) {
    // Remove previous selection
    document.querySelectorAll('.team-selection-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Select new team
    const selectedCard = document.querySelector(`[data-team-id="${teamId}"]`);
    selectedCard.classList.add('selected');
    
    userTeam = teams.find(t => t.id === teamId);
    document.getElementById('confirmBtn').style.display = 'block';
}

function startAuction() {
    if (!userTeam) return;
    
    teamSelectionModal.style.display = 'none';
    
    // Update header with user team info
    document.getElementById('userTeamInfo').style.display = 'flex';
    document.getElementById('selectedTeamName').textContent = userTeam.shortName;
    document.getElementById('selectedTeamPurse').textContent = `₹${userTeam.purse.toFixed(2)} Cr`;
    document.getElementById('myTeamBtn').style.display = 'block';
    
    renderTeams();
    renderPlayersQueue();
    updateAuctionTimer();
    setInterval(updateAuctionTimer, 1000);
    
    // Auto-start with first player
    setTimeout(() => {
        selectNextPlayer();
    }, 2000);
    
    // Add welcome message
    addToAuctionLog(`🎯 Welcome ${userTeam.name}! IPL Auction 2025 is LIVE!`, "system");
    addToAuctionLog("🏏 Ready to build your dream team? Let the bidding begin!", "system");
}

function renderTeams() {
    teamsGridEl.innerHTML = teams.map(team => {
        const isUserTeam = userTeam && team.id === userTeam.id;
        return `
        <div class="team-card ${isUserTeam ? 'user-team' : ''}" 
             style="border-left-color: ${team.color}; ${isUserTeam ? 'background: linear-gradient(135deg, #fff3e0 0%, #ffe0b2 100%); border: 2px solid #ff6b35;' : ''}" 
             onclick="selectTeam(${team.id})">
            <div class="team-name">${team.shortName}</div>
            <div class="team-purse">₹${team.purse.toFixed(2)} Cr</div>
            <div class="team-players">${team.players.length}/${team.maxPlayers} players</div>
            ${isUserTeam ? '<div style="font-size: 0.8rem; color: #ff6b35; font-weight: 600;">YOUR TEAM</div>' : ''}
        </div>
    `;
    }).join('');
}

function renderPlayersQueue() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    let filteredPlayers = playerQueue;
    
    if (categoryFilter !== 'all') {
        filteredPlayers = playerQueue.filter(player => player.category === categoryFilter);
    }
    
    playersQueueEl.innerHTML = filteredPlayers.slice(0, 10).map((player, index) => `
        <div class="player-queue-item ${index === 0 && !currentPlayer ? 'current' : ''} 
                ${player.sold ? 'sold-player' : ''}" 
             onclick="selectPlayer(${player.id})">
            <div class="queue-player-name">${player.name}</div>
            <div class="queue-player-info">
                <span>${player.role}</span>
                <span>₹${player.basePrice} Cr</span>
            </div>
        </div>
    `).join('');
}

function selectPlayer(playerId) {
    const player = players.find(p => p.id === playerId);
    if (!player || player.sold) return;
    
    if (currentPlayer && timerInterval) {
        clearInterval(timerInterval);
    }
    
    currentPlayer = player;
    currentBid = player.basePrice;
    currentBidder = null;
    bidTimer = 15;
    
    renderCurrentPlayer();
    startBidTimer();
    addToAuctionLog(`🎯 ${player.name} is up for auction! Base price: ₹${player.basePrice} Cr`, "player-intro");
}

function selectNextPlayer() {
    const availablePlayers = playerQueue.filter(p => !p.sold);
    if (availablePlayers.length === 0) {
        endAuction();
        return;
    }
    
    const nextPlayer = availablePlayers[0];
    selectPlayer(nextPlayer.id);
}

function renderCurrentPlayer() {
    if (!currentPlayer) {
        document.getElementById('currentPlayer').innerHTML = `
            <div class="player-card">
                <div class="player-details">
                    <h2>Select a player to start auction</h2>
                </div>
            </div>
        `;
        return;
    }
    
    const player = currentPlayer;
    document.getElementById('playerImage').src = player.image;
    document.getElementById('playerName').textContent = player.name;
    document.getElementById('playerRole').textContent = player.role;
    document.getElementById('playerCountry').textContent = player.country;
    document.getElementById('playerAge').textContent = `${player.age} years`;
    document.getElementById('playerCategory').textContent = player.category.toUpperCase();
    
    // Update stats
    const statsEl = document.getElementById('playerStats');
    const stats = player.stats;
    let statsHtml = '';
    
    if (player.role.includes('Batsman') || player.role.includes('keeper')) {
        statsHtml = `
            <div class="stat-item">
                <span class="stat-value">${stats.matches || 0}</span>
                <span class="stat-label">Matches</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.runs || 0}</span>
                <span class="stat-label">Runs</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.average || 0}</span>
                <span class="stat-label">Average</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.strikeRate || 0}</span>
                <span class="stat-label">Strike Rate</span>
            </div>
        `;
    } else if (player.role.includes('Bowler') || player.role.includes('Spinner')) {
        statsHtml = `
            <div class="stat-item">
                <span class="stat-value">${stats.matches || 0}</span>
                <span class="stat-label">Matches</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.wickets || 0}</span>
                <span class="stat-label">Wickets</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.economy || 0}</span>
                <span class="stat-label">Economy</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.average || 0}</span>
                <span class="stat-label">Average</span>
            </div>
        `;
    } else {
        statsHtml = `
            <div class="stat-item">
                <span class="stat-value">${stats.matches || 0}</span>
                <span class="stat-label">Matches</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.runs || 0}</span>
                <span class="stat-label">Runs</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.wickets || 0}</span>
                <span class="stat-label">Wickets</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">${stats.strikeRate || 0}</span>
                <span class="stat-label">Strike Rate</span>
            </div>
        `;
    }
    
    statsEl.innerHTML = statsHtml;
    
    updateBidDisplay();
    updateBidControls();
}

function updateNextBidAmount() {
    const nextBid = currentBid + 0.25;
    document.getElementById('nextBidAmount').textContent = nextBid.toFixed(2);
}

function updateBidDisplay() {
    document.getElementById('currentBid').textContent = `₹${currentBid.toFixed(2)} Cr`;
    document.getElementById('currentBidder').textContent = currentBidder ? currentBidder.shortName : 'No Bids';
    updateNextBidAmount();
}

function updateBidControls() {
    const bidBtn = document.getElementById('bidBtn');
    const passBtn = document.getElementById('passBtn');
    const soldBtn = document.getElementById('soldBtn');
    
    if (userTeam && currentPlayer) {
        const nextBid = currentBid + 0.25;
        const canBid = userTeam.purse >= nextBid && 
                      userTeam.players.length < userTeam.maxPlayers &&
                      (currentPlayer.category !== 'overseas' || userTeam.overseasPlayers < userTeam.maxOverseas);
        
        bidBtn.disabled = !canBid;
        bidBtn.style.display = 'flex';
    } else {
        bidBtn.style.display = 'flex';
        bidBtn.disabled = false;
    }
    
    passBtn.style.display = 'block';
    soldBtn.style.display = 'none';
}

function userBid() {
    if (!userTeam || !currentPlayer) return;
    
    const nextBid = currentBid + 0.25;
    
    // Check if user can afford
    if (userTeam.purse < nextBid) {
        addToAuctionLog("❌ Insufficient funds! You can't afford this bid.", "warning");
        return;
    }
    
    // Check squad limits
    if (userTeam.players.length >= userTeam.maxPlayers) {
        addToAuctionLog("❌ Squad full! You can't buy more players.", "warning");
        return;
    }
    
    // Check overseas limit
    if (currentPlayer.category === 'overseas' && userTeam.overseasPlayers >= userTeam.maxOverseas) {
        addToAuctionLog("❌ Overseas limit reached! You can't buy more overseas players.", "warning");
        return;
    }
    
    currentBid = nextBid;
    currentBidder = userTeam;
    
    updateBidDisplay();
    updateUserTeamInfo();
    resetBidTimer();
    
    addToAuctionLog(`💰 You bid ₹${currentBid.toFixed(2)} Cr for ${currentPlayer.name}!`, "user-bid");
    
    // Bot response
    setTimeout(() => {
        if (currentPlayer && bidTimer > 5 && !autoPlayMode) {
            botBidLogic();
        }
    }, 1000 + Math.random() * 2000);
}

function userPass() {
    if (!currentPlayer) return;
    
    addToAuctionLog(`❌ You passed on ${currentPlayer.name}`, "user-action");
    
    if (currentBidder) {
        soldPlayer();
    } else {
        unsoldPlayer();
    }
}

function updateUserTeamInfo() {
    if (userTeam) {
        document.getElementById('selectedTeamPurse').textContent = `₹${userTeam.purse.toFixed(2)} Cr`;
    }
}

function placeBid() {
    if (!currentPlayer) return;
    
    // Get available teams that can afford the next bid
    const nextBidAmount = currentBid + 0.25;
    let eligibleTeams = teams.filter(team => {
        if (team.purse < nextBidAmount) return false;
        if (currentPlayer.category === 'overseas' && team.overseasPlayers >= team.maxOverseas) return false;
        if (team.players.length >= team.maxPlayers) return false;
        return true;
    });
    
    // Remove user team from bot bidding if not in auto mode
    if (userTeam && !autoPlayMode) {
        eligibleTeams = eligibleTeams.filter(team => team.id !== userTeam.id);
    }
    
    if (eligibleTeams.length === 0) {
        addToAuctionLog("❌ No teams can afford this bid! Player goes unsold.", "warning");
        unsoldPlayer();
        return;
    }
    
    // Random team bids
    const biddingTeam = eligibleTeams[Math.floor(Math.random() * eligibleTeams.length)];
    currentBid = nextBidAmount;
    currentBidder = biddingTeam;
    
    updateBidDisplay();
    if (biddingTeam.id === userTeam?.id) {
        updateUserTeamInfo();
    }
    resetBidTimer();
    
    addToAuctionLog(`💰 ${biddingTeam.shortName} bids ₹${currentBid.toFixed(2)} Cr for ${currentPlayer.name}!`, "bid");
    
    // Bot bidding logic
    setTimeout(() => {
        if (currentPlayer && bidTimer > 5) {
            botBidLogic();
        }
    }, 1000 + Math.random() * 2000);
}

function passPlayer() {
    if (!currentPlayer) return;
    
    if (currentBidder) {
        soldPlayer();
    } else {
        unsoldPlayer();
    }
}

function soldPlayer() {
    if (!currentPlayer || !currentBidder) return;
    
    clearInterval(timerInterval);
    
    // Update player
    currentPlayer.sold = true;
    currentPlayer.team = currentBidder.id;
    currentPlayer.finalPrice = currentBid;
    
    // Update team
    currentBidder.purse -= currentBid;
    currentBidder.players.push(currentPlayer);
    if (currentPlayer.category === 'overseas') {
        currentBidder.overseasPlayers++;
    }
    
    // Update user team info if it's the user's team
    if (currentBidder.id === userTeam?.id) {
        updateUserTeamInfo();
    }
    
    // Show celebration
    document.getElementById('soldBtn').style.display = 'block';
    document.getElementById('bidBtn').style.display = 'none';
    document.getElementById('passBtn').style.display = 'none';
    
    const logType = currentBidder.id === userTeam?.id ? "user-sold" : "sold";
    addToAuctionLog(`🎉 SOLD! ${currentPlayer.name} goes to ${currentBidder.shortName} for ₹${currentBid.toFixed(2)} Cr!`, logType);
    
    renderTeams();
    renderPlayersQueue();
    
    setTimeout(() => {
        selectNextPlayer();
    }, 3000);
}

function unsoldPlayer() {
    if (!currentPlayer) return;
    
    clearInterval(timerInterval);
    
    addToAuctionLog(`😞 ${currentPlayer.name} goes UNSOLD at base price ₹${currentPlayer.basePrice} Cr`, "unsold");
    
    // Remove from queue temporarily
    const playerIndex = playerQueue.findIndex(p => p.id === currentPlayer.id);
    if (playerIndex !== -1) {
        playerQueue.splice(playerIndex, 1);
        playerQueue.push(currentPlayer); // Add to end for potential re-auction
    }
    
    renderPlayersQueue();
    selectNextPlayer();
}

function startBidTimer() {
    bidTimer = 15;
    updateTimerDisplay();
    
    timerInterval = setInterval(() => {
        bidTimer--;
        updateTimerDisplay();
        
        if (bidTimer <= 0) {
            if (currentBidder) {
                soldPlayer();
            } else {
                unsoldPlayer();
            }
        }
    }, 1000);
}

function resetBidTimer() {
    bidTimer = 15;
    updateTimerDisplay();
}

function updateTimerDisplay() {
    const timerEl = document.getElementById('bidTimer');
    const circleEl = document.getElementById('timerCircle');
    
    timerEl.textContent = bidTimer;
    
    const progress = (15 - bidTimer) / 15 * 360;
    circleEl.style.setProperty('--progress', `${progress}deg`);
    
    if (bidTimer <= 5) {
        circleEl.style.animation = 'pulse 0.5s infinite';
    } else {
        circleEl.style.animation = 'none';
    }
}

function updateAuctionTimer() {
    const elapsed = Math.floor((Date.now() - auctionStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    
    document.getElementById('auctionTimer').textContent = 
        `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function addToAuctionLog(message, type = 'info') {
    const timestamp = new Date().toLocaleTimeString();
    const logEntry = {
        message,
        type,
        timestamp
    };
    
    auctionLog.unshift(logEntry);
    if (auctionLog.length > 50) {
        auctionLog.pop();
    }
    
    renderAuctionLog();
}

function renderAuctionLog() {
    auctionLogEl.innerHTML = auctionLog.map(entry => `
        <div class="log-entry log-${entry.type}">
            <span class="log-time">[${entry.timestamp}]</span>
            <span class="log-message">${entry.message}</span>
        </div>
    `).join('');
    
    auctionLogEl.scrollTop = 0;
}

function shufflePlayers() {
    playerQueue = playerQueue.sort(() => Math.random() - 0.5);
    renderPlayersQueue();
    addToAuctionLog("🔀 Player queue has been shuffled!", "system");
}

function filterPlayers() {
    renderPlayersQueue();
}

function selectTeam(teamId) {
    const team = teams.find(t => t.id === teamId);
    const isUserTeam = userTeam && team.id === userTeam.id;
    const prefix = isUserTeam ? "👑 Your Team" : "👥 Viewing";
    addToAuctionLog(`${prefix} ${team.name}: ₹${team.purse.toFixed(2)} Cr remaining, ${team.players.length} players`, "info");
}

function autoPlay() {
    autoPlayMode = !autoPlayMode;
    const btn = document.getElementById('autoPlayBtn');
    
    if (autoPlayMode) {
        btn.innerHTML = '<span class="btn-icon">⏸️</span><span class="btn-text">Stop Auto</span>';
        btn.style.background = 'linear-gradient(135deg, #ff6b35 0%, #ff8a50 100%)';
        addToAuctionLog("🤖 Auto Play enabled! Bot will bid for you.", "system");
    } else {
        btn.innerHTML = '<span class="btn-icon">⚡</span><span class="btn-text">Auto Play</span>';
        btn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        addToAuctionLog("👤 Manual control resumed.", "system");
    }
}

function skipPlayer() {
    if (!currentPlayer) return;
    
    addToAuctionLog(`⏭️ Skipped ${currentPlayer.name}`, "user-action");
    selectNextPlayer();
}

function showMyTeam() {
    if (!userTeam) return;
    
    const modal = document.getElementById('myTeamModal');
    const title = document.getElementById('myTeamTitle');
    const content = document.getElementById('myTeamContent');
    
    title.textContent = `${userTeam.name} Squad`;
    
    const totalSpent = userTeam.players.reduce((sum, player) => sum + player.finalPrice, 0);
    const avgPrice = userTeam.players.length > 0 ? totalSpent / userTeam.players.length : 0;
    
    content.innerHTML = `
        <div class="team-summary">
            <div class="summary-item">
                <span class="summary-value">${userTeam.players.length}</span>
                <span class="summary-label">Players</span>
            </div>
            <div class="summary-item">
                <span class="summary-value">₹${userTeam.purse.toFixed(2)}</span>
                <span class="summary-label">Remaining</span>
            </div>
            <div class="summary-item">
                <span class="summary-value">₹${totalSpent.toFixed(2)}</span>
                <span class="summary-label">Spent</span>
            </div>
            <div class="summary-item">
                <span class="summary-value">${userTeam.overseasPlayers}</span>
                <span class="summary-label">Overseas</span>
            </div>
        </div>
        
        <div class="team-players-list">
            ${userTeam.players.length === 0 ? 
                '<p style="text-align: center; color: #666; padding: 2rem;">No players bought yet. Start bidding!</p>' :
                userTeam.players.map(player => `
                    <div class="team-player-item">
                        <div class="player-basic-info">
                            <div class="player-name-team">${player.name}</div>
                            <div class="player-role-team">${player.role} • ${player.country}</div>
                        </div>
                        <div class="player-price-team">₹${player.finalPrice.toFixed(2)} Cr</div>
                    </div>
                `).join('')
            }
        </div>
    `;
    
    modal.style.display = 'block';
}

function closeMyTeam() {
    document.getElementById('myTeamModal').style.display = 'none';
}

function resetAuction() {
    if (confirm('Are you sure you want to reset the auction? All progress will be lost.')) {
        location.reload();
    }
}

function toggleRules() {
    const modal = document.getElementById('rulesModal');
    modal.style.display = modal.style.display === 'block' ? 'none' : 'block';
}

function endAuction() {
    clearInterval(timerInterval);
    addToAuctionLog("🏁 AUCTION COMPLETED! All players have been processed.", "system");
    addToAuctionLog("🎊 Thank you for participating in IPL Auction 2025!", "system");
    
    // Show final summary
    const soldPlayers = players.filter(p => p.sold);
    addToAuctionLog(`📊 Final Stats: ${soldPlayers.length} players sold, Total spend: ₹${soldPlayers.reduce((sum, p) => sum + p.finalPrice, 0).toFixed(2)} Cr`, "system");
}

// Event Listeners
document.addEventListener('click', (e) => {
    if (e.target === rulesModal || e.target === myTeamModal) {
        toggleRules();
    }
});

// Initialize when page loads
document.addEventListener('DOMContentLoaded', initAuction);