const players = [
    // Indian Capped Players - Batsmen
    {
        id: 1,
        name: "Virat Kohli",
        role: "Batsman",
        country: "India",
        age: 36,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/163390/cricket-player-batsman-game-163390.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 237,
            runs: 7263,
            average: 37.25,
            strikeRate: 131.97
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 2,
        name: "Rohit Sharma",
        role: "Batsman",
        country: "India",
        age: 37,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 258,
            runs: 6628,
            average: 31.17,
            strikeRate: 130.82
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 3,
        name: "Shubman Gill",
        role: "Batsman",
        country: "India",
        age: 25,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 98,
            runs: 2778,
            average: 31.56,
            strikeRate: 135.28
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 4,
        name: "KL Rahul",
        role: "Wicket-keeper",
        country: "India",
        age: 32,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/598917/pexels-photo-598917.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 132,
            runs: 4683,
            average: 47.31,
            strikeRate: 134.62
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 5,
        name: "Rishabh Pant",
        role: "Wicket-keeper",
        country: "India",
        age: 27,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/209978/pexels-photo-209978.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 111,
            runs: 3284,
            average: 35.31,
            strikeRate: 126.37
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Indian Capped Players - All-rounders
    {
        id: 6,
        name: "Hardik Pandya",
        role: "All-rounder",
        country: "India",
        age: 31,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 104,
            runs: 1476,
            wickets: 42,
            strikeRate: 143.89
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 7,
        name: "Ravindra Jadeja",
        role: "All-rounder",
        country: "India",
        age: 36,
        category: "capped",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/3621142/pexels-photo-3621142.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 220,
            runs: 2756,
            wickets: 157,
            economy: 7.68
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 8,
        name: "Washington Sundar",
        role: "All-rounder",
        country: "India",
        age: 25,
        category: "capped",
        basePrice: 1.00,
        image: "https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 62,
            runs: 750,
            wickets: 67,
            economy: 7.25
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Indian Capped Players - Bowlers
    {
        id: 9,
        name: "Jasprit Bumrah",
        role: "Fast Bowler",
        country: "India",
        age: 31,
        category: "capped",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 133,
            wickets: 165,
            economy: 7.30,
            average: 24.43
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 10,
        name: "Mohammed Shami",
        role: "Fast Bowler",
        country: "India",
        age: 34,
        category: "capped",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/598917/pexels-photo-598917.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 106,
            wickets: 195,
            economy: 7.28,
            average: 24.70
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 11,
        name: "Yuzvendra Chahal",
        role: "Leg Spinner",
        country: "India",
        age: 34,
        category: "capped",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 76,
            wickets: 96,
            economy: 7.59,
            average: 22.87
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 12,
        name: "Kuldeep Yadav",
        role: "Leg Spinner",
        country: "India",
        age: 30,
        category: "capped",
        basePrice: 1.00,
        image: "https://images.pexels.com/photos/209978/pexels-photo-209978.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 76,
            wickets: 88,
            economy: 7.56,
            average: 25.68
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Overseas Players - Batsmen
    {
        id: 13,
        name: "David Warner",
        role: "Batsman",
        country: "Australia",
        age: 38,
        category: "overseas",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/3621142/pexels-photo-3621142.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 184,
            runs: 6565,
            average: 41.59,
            strikeRate: 139.96
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 14,
        name: "Jos Buttler",
        role: "Wicket-keeper",
        country: "England",
        age: 34,
        category: "overseas",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/163390/cricket-player-batsman-game-163390.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 107,
            runs: 3582,
            average: 40.25,
            strikeRate: 148.95
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 15,
        name: "Babar Azam",
        role: "Batsman",
        country: "Pakistan",
        age: 30,
        category: "overseas",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 122,
            runs: 4500,
            average: 45.73,
            strikeRate: 129.33
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 16,
        name: "Quinton de Kock",
        role: "Wicket-keeper",
        country: "South Africa",
        age: 32,
        category: "overseas",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/598917/pexels-photo-598917.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 77,
            runs: 2256,
            average: 31.33,
            strikeRate: 129.71
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Overseas All-rounders
    {
        id: 17,
        name: "Ben Stokes",
        role: "All-rounder",
        country: "England",
        age: 33,
        category: "overseas",
        basePrice: 2.00,
        image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 105,
            runs: 2924,
            wickets: 28,
            strikeRate: 135.28
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 18,
        name: "Glenn Maxwell",
        role: "All-rounder",
        country: "Australia",
        age: 36,
        category: "overseas",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/209978/pexels-photo-209978.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 136,
            runs: 2935,
            wickets: 34,
            strikeRate: 154.67
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 19,
        name: "Marcus Stoinis",
        role: "All-rounder",
        country: "Australia",
        age: 35,
        category: "overseas",
        basePrice: 1.00,
        image: "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 74,
            runs: 1488,
            wickets: 32,
            strikeRate: 135.62
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Overseas Bowlers
    {
        id: 20,
        name: "Kagiso Rabada",
        role: "Fast Bowler",
        country: "South Africa",
        age: 29,
        category: "overseas",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/3621142/pexels-photo-3621142.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 64,
            wickets: 87,
            economy: 7.23,
            average: 20.53
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 21,
        name: "Rashid Khan",
        role: "Leg Spinner",
        country: "Afghanistan",
        age: 26,
        category: "overseas",
        basePrice: 1.50,
        image: "https://images.pexels.com/photos/163390/cricket-player-batsman-game-163390.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 106,
            wickets: 153,
            economy: 6.33,
            average: 18.47
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 22,
        name: "Trent Boult",
        role: "Fast Bowler",
        country: "New Zealand",
        age: 35,
        category: "overseas",
        basePrice: 1.00,
        image: "https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 62,
            wickets: 76,
            economy: 7.75,
            average: 25.86
        },
        sold: false,
        team: null,
        finalPrice: 0
    },

    // Uncapped Players
    {
        id: 23,
        name: "Prithvi Shaw",
        role: "Batsman",
        country: "India",
        age: 25,
        category: "uncapped",
        basePrice: 0.50,
        image: "https://images.pexels.com/photos/598917/pexels-photo-598917.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 79,
            runs: 1892,
            average: 26.21,
            strikeRate: 148.88
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 24,
        name: "Ishan Kishan",
        role: "Wicket-keeper",
        country: "India",
        age: 26,
        category: "uncapped",
        basePrice: 0.50,
        image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 105,
            runs: 2644,
            average: 28.21,
            strikeRate: 136.94
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 25,
        name: "Arshdeep Singh",
        role: "Fast Bowler",
        country: "India",
        age: 25,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/209978/pexels-photo-209978.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 65,
            wickets: 76,
            economy: 7.96,
            average: 22.89
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 26,
        name: "Tilak Varma",
        role: "Batsman",
        country: "India",
        age: 22,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/3621104/pexels-photo-3621104.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 35,
            runs: 794,
            average: 28.35,
            strikeRate: 140.25
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 27,
        name: "Abhishek Sharma",
        role: "All-rounder",
        country: "India",
        age: 24,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/3621142/pexels-photo-3621142.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 42,
            runs: 1014,
            wickets: 8,
            strikeRate: 158.75
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 28,
        name: "Ravi Bishnoi",
        role: "Leg Spinner",
        country: "India",
        age: 24,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/163390/cricket-player-batsman-game-163390.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 54,
            wickets: 63,
            economy: 7.87,
            average: 25.32
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 29,
        name: "Mohsin Khan",
        role: "Fast Bowler",
        country: "India",
        age: 26,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/209977/pexels-photo-209977.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 24,
            wickets: 27,
            economy: 7.23,
            average: 19.78
        },
        sold: false,
        team: null,
        finalPrice: 0
    },
    {
        id: 30,
        name: "Ayush Badoni",
        role: "Batsman",
        country: "India",
        age: 24,
        category: "uncapped",
        basePrice: 0.20,
        image: "https://images.pexels.com/photos/598917/pexels-photo-598917.jpeg?auto=compress&cs=tinysrgb&w=300",
        stats: {
            matches: 36,
            runs: 711,
            average: 26.33,
            strikeRate: 142.68
        },
        sold: false,
        team: null,
        finalPrice: 0
    }
];